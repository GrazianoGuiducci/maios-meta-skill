---
name: ricostruire-lavoro-decisioni
description: "Mantiene una traccia degli eventi materiali e distingue la fonte dell’operatore dalle interpretazioni dell’assistente e dagli effetti osservati. Quando cambiano requisiti e direzione o serve ricostruire perché un progetto si trova nello stato attuale."
---

# D-ND Material Work Continuity

**Ricostruire il lavoro e le decisioni di un progetto AI**

Conserva richieste originali, azioni, correzioni e punto attuale senza riscrivere ciò che è avvenuto.

## Scopo e situazione

Mantiene una traccia degli eventi materiali e distingue la fonte dell’operatore dalle interpretazioni dell’assistente e dagli effetti osservati.

Usa questa competenza: quando cambiano requisiti e direzione o serve ricostruire perché un progetto si trova nello stato attuale.

Una decisione può cambiare senza cancellare ciò che è avvenuto prima. Questa competenza conserva il collegamento fra richiesta originale, interpretazione dell'AI, lavoro svolto e correzione successiva.

Il risultato è una ricostruzione utilizzabile da chi riprende il progetto. La storia dettagliata resta raggiungibile; il punto corrente contiene quanto serve per continuare.

## Conservare la fonte prima del racconto

Quando una richiesta, una decisione o una correzione cambia materialmente il lavoro, conserva le parole originali o un riferimento esatto alla fonte accessibile nel progetto. Mantieni incertezze e formulazioni insolite. Attribuisci separatamente il riassunto dell'assistente e le sue inferenze. Se la fonte manca, dichiara la parte non ricostruibile: non ricreare una citazione da un ricordo o da un riepilogo. Usa il luogo di continuità già presente quando è adeguato.

## Seguire eventi ed effetti

Registra soltanto gli eventi che cambiano la ricostruzione: una fonte, una proposta dell'AI, un'azione con riscontro, una correzione, un cambiamento delle autorizzazioni o un'incognita decisiva. Collega ogni effetto alla sua prova e al momento in cui è stato osservato. Un file preparato, un invio eseguito e una risposta ricevuta sono fatti diversi. Conserva l'azione effettiva anche se il piano che l'ha prodotta viene successivamente abbandonato.

## Correggere senza riscrivere il passato

Una correzione aggiunge una nuova relazione alla storia: indica quale interpretazione o istruzione supera e quale seguito cambia. Non cancellare l'evento precedente né attribuire al passato una comprensione emersa dopo. La revoca di un permesso cambia ciò che si può fare ora, non annulla un effetto già avvenuto. Una sintesi dell'AI non può creare un'autorizzazione: conserva il riferimento alla decisione della persona o del responsabile effettivo.

## Rendere ricostruibile il punto corrente

Mantieni un ingresso breve che colleghi fonti ancora valide, decisioni, effetti compiuti, incognite e prossimo movimento pertinente. Il registro dettagliato e l'ingresso corrente svolgono funzioni diverse. Se la complessità lo richiede, usa eventi identificati e riferimenti ai predecessori; altrimenti bastano note attribuite e datate. Nel riprendere verifica che i riferimenti utili siano raggiungibili e segnala contenuti mancanti o cambiati. Non dichiarare copertura di una fonte non letta.

## Proteggere il lavoro e migliorare la ricostruzione

Scrivi nel progetto selezionato e preserva contributi concorrenti; se la destinazione di persistenza manca, prepara una nota che la persona possa conservare. Non costruire un diario universale. Escludi segreti e dati privati estranei, senza conservarne impronte derivate. Quando una ripresa rivela una perdita causale, correggi il modo in cui la continuità viene mantenuta: la nuova nota deve permettere una ricostruzione migliore, non soltanto aggiungere volume.

## Profondità del metodo

Questa competenza opera sulla continuità materiale: conserva che cosa è accaduto e da quali fonti deriva. Non decide da sola il significato di una scelta né lo stato complessivo del progetto.

La relazione diventa meta quando un errore di ricostruzione cambia il metodo con cui si conserva il lavoro. Per esempio, un riepilogo aveva mescolato proposta e approvazione: il seguito rende riconoscibili entrambe. Non è autonomia esecutiva, e un registro ben formato non dimostra memoria infallibile.

## Continuità e apprendimento

Un passaggio di consegne mostra quali collegamenti sono sufficienti e quali mancano. Conserva la correzione nel metodo di continuità, lasciando le scelte di progetto al loro responsabile.

Nel primo uso, parti dal contesto e dalle fonti effettivamente disponibili. Il metodo può essere esercitato in chat; persistenza, strumenti e azioni esterne dipendono dai mezzi e dal mandato del destinatario. Le istruzioni rendono la capacità utilizzabile, mentre il suo comportamento e il suo valore richiedono osservazione nel lavoro reale.
