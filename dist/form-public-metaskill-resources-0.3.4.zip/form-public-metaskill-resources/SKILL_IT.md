---
name: form-public-metaskill-resources
description: "Turn an internal competence into a usable public resource. Use when preserving portable functions, removing private dependencies, preparing an installable kit, explaining first use or connecting repository, resource pages and editorial adaptations."
metadata:
  version: 0.3.4
  language: it
---

# Form Public Meta-Skill Resources

Forma una risorsa utilizzabile fuori dal contesto d’origine, conservando il metodo e rendendo chiaro come iniziare nella propria AI.

**Trasformare una competenza interna in una risorsa pubblica**

Questa metacompetenza trasforma un saper fare interno in una risorsa che persone e assistenti esterni possono comprendere, avviare e adattare. Tiene insieme metodo trasferito, guida, primo uso, repository o altro luogo di distribuzione, pagina di presentazione e derivazioni editoriali.

La risorsa nasce dal lavoro che il destinatario potrà affidarle. Una funzione concreta, una competenza o una composizione possono essere utili: il nome “meta” non ne determina da solo il valore.

## Una biblioteca prepara, continua e condivide un metodo di laboratorio

La biblioteca seleziona la pubblicazione del metodo dei laboratori.

Segui ogni funzione materiale dal sapere sorgente all’ingresso operativo consumato dal destinatario: kit, avvio, pagina o contesto dell’assistente. Conserva decisioni, ragioni, strumenti forniti e adattamenti locali. Se un assistente usa uno snapshot separato del sapere, la sola pagina aggiornata lascia invariato quel passaggio. Correggi la prima trasformazione responsabile e i suoi dipendenti effettivi. Ogni osservazione resta legata all’edizione esercitata, mentre l’apprendimento riusabile ritorna al metodo di formazione.

## Adattare il metodo al proprio lavoro e ambiente

Ricerca, educazione, software, servizi e progetti culturali portano fonti e scelte diverse. Porta lavoro, sapere esistente e mezzi realmente disponibili. Il caso della biblioteca insegna relazioni adattabili; non prescrive il tuo progetto.

Una conversazione usa l’avvio completo e restituisce una guida da salvare. Un sistema con accesso ai file conserva il kit intero e lo collega attraverso l’ingresso nativo dell’ambiente. Un kernel esistente compone il contributo pertinente con le proprie competenze e l’apprendimento locale.

## Partire dalla capacità e dal destinatario

Leggi la competenza sorgente, le ragioni della sua formazione e la guida del lavoro. Comprendi che cosa il ricevente potrà fare, quando gli servirà e quale conoscenza gli permetterà di adattare il metodo. Cerca il sapere anche nelle guide e nelle relazioni con altre capacità: una cartella o una descrizione non esauriscono la funzione. Quando la risorsa compone più competenze, trasferisci il ponte che collega conoscenza e scelta; un elenco di nomi lascia quel lavoro al destinatario.


## Formare un metodo utilizzabile fuori dal contesto d’origine

Preserva significato, ragioni, capacità e possibilità di revisione. Sostituisci dipendenze private con conoscenza inclusa o fonti accessibili. Togliere percorsi e nomi non basta: il ricevente deve sapere cosa osservare, quale relazione cambia una decisione e come continuare. Mantieni le condizioni che rendono vera una lezione e distingui metodo proposto, capacità implementata, esercizio osservato e assimilazione. Gli esempi nuovi restano illustrativi. Rimuovi credenziali, stato degli account, contatti, cronologie e dettagli privati non necessari.


## Costruire corpo, guida e primo uso

Forma il corpo operativo nella profondità richiesta dal lavoro. La guida spiega come usarlo e adattarlo; gli esempi rendono riconoscibili casi differenti. Un avvio dichiarato autonomo deve includere il metodo necessario; un ingresso che rimanda a file deve raggiungere file effettivamente disponibili. Spiega le differenze fra chat, ambiente agentico e kernel esistente dove cambiano l’uso. Indica come conservare il sapere attraverso documenti o un testo da salvare. Le istruzioni non installano strumenti, memoria, account o scheduler.


## Presentare la capacità senza perdere profondità

La scheda rende immediati cosa fa, quando usarla e casi riconoscibili. Titolo e sottotitolo identificano l’oggetto e il contesto per chi non conosce il progetto. La pagina dedicata rende raggiungibili spiegazione del metodo, avvio, esempi e profondità concettuale pertinente. Chiarisci quale oggetto viene trasformato: una relazione meta forma o modifica metodi e competenze; una relazione autologica riguarda il proprio modo di operare. Composizione, automazione e autonomia non sono sinonimi di questi concetti.


## Far continuare la stessa risorsa nelle sue proiezioni

Assegna un’identità e una versione coerenti a corpo, guida, avvio e presentazione. Quando un pacchetto dichiara una revisione, costruiscilo dagli stessi contenuti e verifica quella corrispondenza; non attribuire a una versione file concorrenti diversi. Gli articoli e gli adattamenti derivano dalla capacità selezionata: la riduzione conserva tesi, stato e condizioni, la traduzione conserva significato. Preserva gli originali umani distinguendoli dalle proposte dell’assistente. Sorgente condivisa, anteprima, deploy, invio e uso da parte di altri sono effetti e osservazioni distinti, governati dal mandato e dai mezzi reali.

Conserva l'identificatore canonico dell'ingresso e l'intestazione sorgente con la sua attribuzione. La denominazione pubblica può usare la lingua principale della raccolta quando identifica la stessa competenza; usa quella denominazione in entrambe le edizioni linguistiche. Mantieni nomi propri come KA, Meta_Metodo e Proto Movimento. I titoli funzionali spiegano che cosa fa la competenza e rimangono distinti dal nome e dall'identificatore. Verifica queste relazioni con la sorgente nativa, oltre al catalogo che potrebbe ripetere una sostituzione editoriale.


## Una risorsa che insegna anche a formare risorse

La relazione meta è il suo oggetto: forma una capacità utilizzabile a partire da un sapere interno e ne collega gli ingressi. Lo stesso metodo può essere applicato alla propria trasformazione in risorsa pubblica.

La relazione autologica compare quando una difficoltà del destinatario corregge il metodo di formazione: se il prompt rinvia a una guida privata, non manca solo un link, manca conoscenza operativa nel ricevente. Quel riscontro cambia come il prossimo kit viene costruito. Il ritorno al metodo non implica distribuzione autonoma.


## Seguire la capacità fino a ciò che il destinatario riceve davvero

Segui ogni funzione materiale dal sapere sorgente all’ingresso operativo consumato dal destinatario: kit, avvio, pagina o contesto dell’assistente. Conserva decisioni, ragioni, strumenti forniti e adattamenti locali. Se un assistente usa uno snapshot separato del sapere, la sola pagina aggiornata lascia invariato quel passaggio. Correggi la prima trasformazione responsabile e i suoi dipendenti effettivi. Ogni osservazione resta legata all’edizione esercitata, mentre l’apprendimento riusabile ritorna al metodo di formazione.

## Continuare attraverso il progetto reale

Un problema di comprensione cambia la scheda o la spiegazione; una lacuna d’uso cambia metodo, guida o attivazione; una divergenza fra sorgente e pacchetto cambia il meccanismo di costruzione. Correggi le proiezioni realmente dipendenti, preservando gli altri lavori.

Conserva fonte, ragione e conseguenza che miglioreranno la prossima risorsa. Una prima realizzazione rende il metodo disponibile e documenta il proprio caso; una diversa adozione successiva può mostrarne limiti e capacità.

## Sapere operativo

Leggi GUIDA_OPERATIVA_IT.md ed ESEMPI_IT.md. Senza accesso ai file usa AVVIO_CHAT_IT.txt completo. Il metodo si compone con le competenze complementari del progetto; strumenti effettivi, persistenza ed effetti autorizzati appartengono al ricevente.
