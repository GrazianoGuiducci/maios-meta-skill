# Installare Transfer Kernel Potential

Conserva insieme l’intera cartella `transfer-kernel-potential`. Estrai lo ZIP e copia la cartella in `.agents/skills/` del progetto. Preserva una copia esistente e il sapere che ha acquisito, senza sovrascriverla. Apri Codex nel progetto e richiama `$transfer-kernel-potential` con un incarico concreto. Riavvia la sessione se la skill non compare. Puoi chiedere risposte italiane; l’entry canonica resta inglese.

Leggi GUIDA_OPERATIVA_IT.md e osserva il primo uso nel progetto reale. Discovery, lavoro utile e apprendimento successivo restano distinti. In un altro ambiente usa il suo meccanismo nativo o allega AVVIO_CHAT_IT.txt a una chat.

[Guida di installazione](https://github.com/GrazianoGuiducci/maios-meta-skill/blob/main/docs/INSTALL_IT.md)
