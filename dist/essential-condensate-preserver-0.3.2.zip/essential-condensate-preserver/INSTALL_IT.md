# Installare Essential Condensate Preserver in Codex

Questo kit è alla versione 0.3.2. Conserva tutti i file della cartella `essential-condensate-preserver`.

1. Estrai lo ZIP scaricato.
2. Copia `essential-condensate-preserver` nella directory `.agents/skills/` del progetto. L'ingresso è `.agents/skills/essential-condensate-preserver/SKILL.md`. Conserva un'eventuale cartella esistente, senza sovrascriverla.
3. Apri Codex nel progetto e richiama `$essential-condensate-preserver` con intento concreto e fonti pertinenti. Riavvia la sessione se l'ingresso non compare.

Per lavorare in italiano chiedi un risultato italiano; l'ingresso installato rimane inglese e SKILL_IT.md è disponibile. Leggi GUIDA_OPERATIVA_IT.md e osserva il primo uso con i mezzi reali. Presenza nel selettore, lavoro utile e apprendimento successivo sono osservazioni distinte. Confronta gli aggiornamenti con il sapere locale prima di integrarli.

[Installer della repository e aggiornamenti](https://github.com/GrazianoGuiducci/maios-meta-skill/blob/main/docs/INSTALL_IT.md) · [Uso in chat](README_IT.md)

[OpenAI skill documentation](https://learn.chatgpt.com/docs/build-skills).
