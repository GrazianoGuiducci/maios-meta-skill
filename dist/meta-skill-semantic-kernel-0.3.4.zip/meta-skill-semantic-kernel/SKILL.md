---
name: meta-skill-semantic-kernel
description: "Recognize, compose, form and evolve competences through actual work. Use when a capability is missing, complementary knowledge changes a task, examples should become reusable know-how, or competence formation itself needs to learn."
metadata:
  version: 0.3.4
  language: en
---

# Meta_Skill Semantic Kernel

Recognizes relevant capabilities, reuses or composes existing ones and forms the operating knowledge a continuing competence needs.

Useful work can leave both a result and new know-how. Meta_Skill makes that relation usable: recognizing capabilities, composing them and forming what lets a system act in its actual context.

Knowledge, exemplary works, explanations, successes, corrections and possibilities can all contribute. The method connects what is learned to the choices that should change.

## A library forms and shares its workshop method

The library brings a teacher’s objective, two permitted excerpts and a librarian’s annotated session plan.

An intention can change which sources, questions and competences participate before any finished result exists. Reuse an existing method when it already carries the useful relation; deepen its knowledge or repair its entry where needed. A new continuing capability can also emerge from success, teaching or a possibility. Preserve useful determinations and let the next result reform how capabilities are formed.

## Adapt the capability through your own work

Education, research, services and cultural work supply different sources and choices. Bring your purpose, an existing method or example, and the means actually available. Preserve what makes a choice useful when the situation changes.

The receiving system may be conversational, file-enabled, tool-connected or organized through an existing kernel. Use its actual entry and continuity; the library case teaches a relationship, not a required project shape or provider.

## Generative work

KA, Kernel Assiomatico, is a semantic kernel; metacompetences are its operating faculties. Meta_Skill operates on this competence field. Do not reduce KA to a substrate under a separately conceived Meta_Skill kernel.

Recognize, reuse, compose, form and evolve competences that can change present work. Begin from intent, sources and available capabilities, allowing new knowledge to change the question too. A competence is operating knowledge for understanding a situation, choosing action and using consequences. Its file is an entry, not the entire capability.

Understand what the recipient should be able to do, why and under which conditions. A useful result, example, teaching, memory, error or possibility can inform formation; diagnosing a defect is not a prerequisite. Keep unrepresented relations reachable while preserving determinations actually reached.


## From knowledge to decisions

Read sources needed to understand the doing. Derive the relation between purpose, conditions, choice and consequence from examples, without confusing visible form with mechanism. A useful cost estimate, for example, may teach how to make alternatives and assumptions comparable; copying its sections loses that relation. Teaching may explain a choice an example leaves implicit. Practice in another situation can correct both.

Make that knowledge operational: what to observe, which difference changes a decision, how to construct the result, when to adapt and which consequence calls for revision. These questions aid understanding rather than forming compulsory fields. Keep reasons and decisive sources in a reachable guide so changing conditions can reform the method.


## Reuse, composition and formation

Let an existing competent capability participate. Reconnect its entry when knowledge exists but is not found. Deepen the responsible method when an operating relation is missing. Form the smallest usable body when a distinct capability needs continuity of its own.

Research, analysis and writing can contribute to one result, changing question and method while preserving their sources. Do not predetermine every competence, order or pass count. A temporary composition may end with the task; a continuing shared relation that learns may warrant its own location.

The formed method must know its enabling conditions. Do not merely instruct “analyze well” or “preserve context”: teach how a source, contradiction or consequence changes the relevant choice. Include a recognizable entry, knowledge for action and a continuation guide. When a technical skill is needed, use the recipient's supported format without allowing format to determine capability.


## Apply and reform

Exercise the method in selected real work. Keep source, object, meaning, method and consequence connected as the result forms. If a synthesis changed the author's concept, recover the faithful relation before continuing. Let new observations change composition when they open a different possibility. Internal coherence can coexist with loss of the object.

When experience changes know-how, integrate the difference into the competence that continues. Preserve the cause changing later use, not only an error report. Several competences may receive different changes from one event. A domain lesson does not automatically become a general rule.


## The generator as an object of its own work

This method is itself a competence. If formation copied an example's appearance and another case exposes lost conditions, change both the skill and the method extracting knowledge from examples. That return is autological: the generator understands and reforms its doing in the same field. It is autopoietic when it changes the form through which further generation and work become possible.

Meta levels follow the object: preparing a cost estimate, forming the capability to prepare cost estimates, improving how those capabilities are formed. They are not a fixed rank or quality measure. Autonomy concerns actions the environment can perform within its entrusted mandate without intervention.

Preserve acquired understanding before context loss makes it unreachable. At reentry, reach the present and still-valid reasons rather than reinstalling an earlier conclusion as immutable truth. Continue while another difference changes the work; when rereading only adds procedure, proceed from the sufficient result.


## Use and continuity in the recipient

Use actual means: supplied materials in chat, or files, tools and guides where available. Ask for missing context only when it changes the work. Preserve reasons, sources, learned differences and continuation in the project's actual location; without persistence, return a reusable note.

Instructions make knowledge available without updating model weights or proving stable learning. Distinguish available method, actual use and later observed behavior. Accounts, tools and authority over publication, sending, installation and distribution depend on the actual environment and mandate.


## Nature and provenance

Public adaptation of the generative Meta_Skill kernel in its relation with KA and FDLA, including formation from works, teaching and practice. It transfers a formation and composition method rather than a particular node's state or a guarantee of model self-learning.


## Recognize and form capability while the work takes shape

An intention can change which sources, questions and competences participate before any finished result exists. Reuse an existing method when it already carries the useful relation; deepen its knowledge or repair its entry where needed. A new continuing capability can also emerge from success, teaching or a possibility. Preserve useful determinations and let the next result reform how capabilities are formed.

## Continue through the actual project

A new source can change which other sources seem relevant. Formation retains this openness even when a useful method already exists.

The first edition makes operating knowledge available. Use in different situations can show and refine its transfer.

## Operating knowledge

Read OPERATING_GUIDE.md and EXAMPLES.md. With no file access, use the complete START_CHAT_EN.txt. The method composes with complementary project competences; actual tools, persistence and authorized effects belong to the receiving environment.
