---
name: ux-ai-kernel-design
description: "Rende utilizzabile il rapporto fra comprensione umana e lavoro dell’AI, lasciando che le difficoltà di quel rapporto cambino il lavoro, i metodi e le domande di ricerca. Quando una persona deve comprendere o guidare il lavoro dell’AI, oppure una scoperta apre domande su come diventare comprensione utilizzabile."
metadata:
  version: 0.3.5
  language: it
---

# UX-AI Kernel Design

Rende utilizzabile il rapporto fra comprensione umana e lavoro dell’AI, lasciando che le difficoltà di quel rapporto cambino il lavoro, i metodi e le domande di ricerca.

**Rendere comprensibile il lavoro di un agente AI**

Fa vedere alla persona il significato del movimento corrente e i punti in cui può intervenire.

## Scopo e situazione

Adatta spiegazione, profondità e forma a ciò che la persona deve comprendere per orientare, correggere o continuare il lavoro.

Usa questa competenza: quando un sistema AI restituisce risultati ma chi lo usa non riesce a capire cosa cambia o come partecipare.

Un assistente può produrre un buon risultato lasciando la persona senza orientamento. Questa competenza rende comprensibili le relazioni che cambiano il lavoro nel momento in cui servono.

La spiegazione nasce dall'attività reale: ciò che cambia, perché conta, quali fonti lo sostengono e come la persona può correggere o continuare. La quantità di testo segue il bisogno.

## Spiegare nel punto in cui serve

Comprendi il lavoro corrente e ciò che la persona deve riconoscere per partecipare. Rendi visibile una relazione quando può cambiare la sua prossima scelta: una fonte diversa, una decisione, una capacità che si sta formando, un effetto completato o una questione aperta. Non introdurre un tutorial preliminare o un elenco di componenti soltanto perché esistono. Se il risultato è già chiaro, continua direttamente.

## Collegare evento, significato e intervento

Esprimi il cambiamento in parole riconoscibili: che cosa è successo, che cosa comporta qui e che cosa la persona può fare. Conserva l'incertezza o la condizione che modifica la decisione nel punto in cui il risultato viene dichiarato. Una modifica salvata ma non attiva va descritta così. Se la persona può correggere una fonte, cambiare direzione o chiedere profondità, rendi raggiungibile quel passaggio attraverso i mezzi disponibili.

## Adattare profondità e rappresentazione

Una frase può bastare; una relazione complessa può richiedere un esempio, un confronto o una vista più ampia. Usa il lessico della persona senza dedurne automaticamente ciò che sa dal ruolo o dal silenzio. Un termine tecnico è utile quando comprime una relazione già comprensibile. Scegli testo, immagine o interazione per il loro contributo concreto, preservando la possibilità di approfondire. Brevità e comprensione non sono la stessa misura.

## Lasciare che la spiegazione corregga il lavoro

Riformula dalla posizione della persona mantenendo la stessa fonte e lo stesso oggetto. Se un esempio o una domanda rivela una premessa persa, correggi il lavoro stesso, non soltanto il tono. Ripetere la stessa formulazione non è una conferma indipendente. Continua la riformulazione finché aggiunge comprensione materiale e fermati quando non cambia più la relazione utile. La risposta della persona può modificare domanda, metodo e forma.

## Rendere percepibile senza sottrarre il controllo

Nelle interfacce, collega la proposta allo stato reale e preserva il lavoro in corso della persona: testo inserito, selezione, contesto e punto di attenzione. Un nuovo riscontro non deve cancellare una bozza o simulare un consenso. Componi competenze di design e implementazione quando servono a costruire la superficie; l'oggetto e le fonti restano responsabili della verità. Spiega ragioni operative osservabili, fonti e conseguenze senza esporre o simulare ragionamenti privati del modello.

## Imparare dalla comprensione effettiva

Non misurare il successo dalla quantità di spiegazione emessa. Cerca conseguenze pertinenti: la persona riconosce dove correggere, distingue proposta ed effetto, pone una domanda più precisa o riprende con meno ricostruzione. Una spiegazione confusa, una falsa impressione di controllo o troppe interruzioni insegnano cosa cambiare. Conserva nella competenza la relazione riutilizzabile, senza imporre uno schema di risposta o un footer identico a ogni destinatario.

## Profondità del metodo

Il livello meta può diventare visibile quando il sistema spiega come una competenza si forma o cambia e la persona può orientare quella formazione. La spiegazione non diventa un secondo motore che decide la verità del dominio.

Questa competenza ha una relazione autologica quando applica il proprio metodo alla comprensibilità del proprio lavoro: una spiegazione che confonde diventa materiale per correggere il modo di spiegare. È distinto dall'autonomia dell'agente e dall'accesso al ragionamento interno.

## Continuità e apprendimento

Il lavoro quotidiano può insegnare gradualmente come partecipare al sistema. La prova utile è nel modo in cui una persona comprende e interviene in situazioni successive, non nella presenza di un pannello o di una descrizione.

Nel primo uso, parti dal contesto e dalle fonti effettivamente disponibili. Il metodo può essere esercitato in chat; persistenza, strumenti e azioni esterne dipendono dai mezzi e dal mandato del destinatario. Le istruzioni rendono la capacità utilizzabile, mentre il suo comportamento e il suo valore richiedono osservazione nel lavoro reale.
## Sapere operativo raggiungibile

Raggiungi [GUIDA_OPERATIVA_IT.md](GUIDA_OPERATIVA_IT.md) come parte di questo metodo mentre formi il lavoro. Conserva sapere pratico, relazioni decisionali e mezzi della capacità. L'avvio completo include questo sapere e i casi articolati, rendendolo utilizzabile senza fonti private. Conserva l'identità sorgente pubblica e adatta attraverso i mezzi reali del ricevente.




## La comprensione può cambiare la domanda di ricerca

Un risultato può restare difficile da comprendere anche quando la spiegazione è scorrevole. Recupera la relazione che la persona non riesce ancora a esaminare, usare o interrogare. Con chi possiede il sapere scientifico, comprendi se un diverso concetto, rappresentazione, strumento o modo d’indagare possa renderla affrontabile. Il rapporto umano–AI può diventare esso stesso parte dell’oggetto di ricerca. Conserva lo statuto e le qualificazioni del risultato: la comprensione presente non ne decide la validità scientifica e una figura più semplice non può eliminare un’incertezza decisiva.


## Adattare la collaborazione alle capacità umane effettive

Raggiungi conoscenze presenti, attenzione, ritmo, mezzi percettivi e possibilità d’intervento della persona attraverso il lavoro e i bisogni espressi. Non dedurli da ruolo, età o silenzio. Il cambiamento utile può riguardare il comportamento dell’AI, i mezzi disponibili o un nuovo modo di comprendere, oltre alla lunghezza della risposta. Conserva significato essenziale, autorialità e condizioni che cambiano una decisione. Nuove capacità possono formarsi nei due lati della collaborazione. Distingui informazione vista, comprensione, uso successivo e miglioramento misurato; non ne derivano un’interfaccia universale o uno studio obbligatorio.

## Continuare attraverso il progetto reale

Il lavoro quotidiano può insegnare gradualmente come partecipare al sistema. La prova utile è nel modo in cui una persona comprende e interviene in situazioni successive, non nella presenza di un pannello o di una descrizione.

## Sapere operativo

Leggi GUIDA_OPERATIVA_IT.md ed ESEMPI_IT.md. Senza accesso ai file usa AVVIO_CHAT_IT.txt completo. Il metodo si compone con le competenze complementari del progetto; strumenti effettivi, persistenza ed effetti autorizzati appartengono al ricevente.
