---
name: form-public-metaskill-resources
description: "Turn an internal competence into a usable public resource. Use when preserving portable functions, removing private dependencies, preparing an installable kit, explaining first use or connecting repository, resource pages and editorial adaptations."
metadata:
  version: 0.3.6
  language: it
---

# Form Public Meta-Skill Resources

Forma una risorsa utilizzabile fuori dal contesto d’origine, conservando il metodo e rendendo chiaro come iniziare nella propria AI.

**Trasformare una competenza interna in una risorsa pubblica**

Questa metacompetenza trasforma un saper fare interno in una risorsa che persone e assistenti esterni possono comprendere, avviare e adattare. Tiene insieme metodo trasferito, guida, primo uso, repository o altro luogo di distribuzione, pagina di presentazione e derivazioni editoriali.

La risorsa nasce dal lavoro che il destinatario potrà affidarle. Una funzione concreta, una competenza o una composizione possono essere utili: il nome “meta” non ne determina da solo il valore.

## Una biblioteca prepara, continua e condivide un metodo di laboratorio

La biblioteca seleziona la pubblicazione del metodo dei laboratori.

Segui ogni funzione materiale dal sapere sorgente all’ingresso operativo consumato dal destinatario: kit, avvio, pagina o contesto dell’assistente. Conserva decisioni, ragioni, strumenti forniti e adattamenti locali. Se un assistente usa uno snapshot separato del sapere, la sola pagina aggiornata lascia invariato quel passaggio. Correggi la prima trasformazione responsabile e i suoi dipendenti effettivi. Ogni osservazione resta legata all’edizione esercitata, mentre l’apprendimento riusabile ritorna al metodo di formazione.

## Adattare il metodo al proprio lavoro e ambiente

Ricerca, educazione, software, servizi e progetti culturali portano fonti e scelte diverse. Porta lavoro, sapere esistente e mezzi realmente disponibili. Il caso della biblioteca insegna relazioni adattabili; non prescrive il tuo progetto.

Una conversazione usa l’avvio completo e restituisce una guida da salvare. Un sistema con accesso ai file conserva il kit intero e lo collega attraverso l’ingresso nativo dell’ambiente. Un kernel esistente compone il contributo pertinente con le proprie competenze e l’apprendimento locale.

## Partire dalla capacità e dal destinatario

Leggi la competenza sorgente, le ragioni della sua formazione e la guida del lavoro. Comprendi che cosa il ricevente potrà fare, quando gli servirà e quale conoscenza gli permetterà di adattare il metodo. Cerca il sapere anche nelle guide e nelle relazioni con altre capacità: una cartella o una descrizione non esauriscono la funzione. Quando la risorsa compone più competenze, trasferisci il ponte che collega conoscenza e scelta; un elenco di nomi lascia quel lavoro al destinatario.


## Formare un metodo utilizzabile fuori dal contesto d’origine

Preserva significato, ragioni, capacità e possibilità di revisione. Sostituisci dipendenze private con conoscenza inclusa o fonti accessibili. Togliere percorsi e nomi non basta: il ricevente deve sapere cosa osservare, quale relazione cambia una decisione e come continuare. Mantieni le condizioni che rendono vera una lezione e distingui metodo proposto, capacità implementata, esercizio osservato e assimilazione. Gli esempi nuovi restano illustrativi. Rimuovi credenziali, stato degli account, contatti, cronologie e dettagli privati non necessari.


## Costruire corpo, guida e primo uso

Forma il corpo operativo nella profondità richiesta dal lavoro. La guida spiega come usarlo e adattarlo; gli esempi rendono riconoscibili casi differenti. Un avvio dichiarato autonomo deve includere il metodo necessario; un ingresso che rimanda a file deve raggiungere file effettivamente disponibili. Spiega le differenze fra chat, ambiente agentico e kernel esistente dove cambiano l’uso. Indica come conservare il sapere attraverso documenti o un testo da salvare. Le istruzioni non installano strumenti, memoria, account o scheduler.


## Presentare la capacità senza perdere profondità

La scheda rende immediati cosa fa, quando usarla e casi riconoscibili. Titolo e sottotitolo identificano l’oggetto e il contesto per chi non conosce il progetto. La pagina dedicata rende raggiungibili spiegazione del metodo, avvio, esempi e profondità concettuale pertinente. Chiarisci quale oggetto viene trasformato: una relazione meta forma o modifica metodi e competenze; una relazione autologica riguarda il proprio modo di operare. Composizione, automazione e autonomia non sono sinonimi di questi concetti.


## Far continuare la stessa risorsa nelle sue proiezioni

Assegna un’identità e una versione coerenti a corpo, guida, avvio e presentazione. Quando un pacchetto dichiara una revisione, costruiscilo dagli stessi contenuti e verifica quella corrispondenza; non attribuire a una versione file concorrenti diversi. Gli articoli e gli adattamenti derivano dalla capacità selezionata: la riduzione conserva tesi, stato e condizioni, la traduzione conserva significato. Preserva gli originali umani distinguendoli dalle proposte dell’assistente. Sorgente condivisa, anteprima, deploy, invio e uso da parte di altri sono effetti e osservazioni distinti, governati dal mandato e dai mezzi reali.

Conserva l'identificatore canonico dell'ingresso e l'intestazione sorgente con la sua attribuzione. La denominazione pubblica può usare la lingua principale della raccolta quando identifica la stessa competenza; usa quella denominazione in entrambe le edizioni linguistiche. Mantieni nomi propri come KA, Meta_Metodo e Proto Movimento. I titoli funzionali spiegano che cosa fa la competenza e rimangono distinti dal nome e dall'identificatore. Verifica queste relazioni con la sorgente nativa, oltre al catalogo che potrebbe ripetere una sostituzione editoriale.


## Una risorsa che insegna anche a formare risorse

La relazione meta è il suo oggetto: forma una capacità utilizzabile a partire da un sapere interno e ne collega gli ingressi. Lo stesso metodo può essere applicato alla propria trasformazione in risorsa pubblica.

La relazione autologica compare quando una difficoltà del destinatario corregge il metodo di formazione: se il prompt rinvia a una guida privata, non manca solo un link, manca conoscenza operativa nel ricevente. Quel riscontro cambia come il prossimo kit viene costruito. Il ritorno al metodo non implica distribuzione autonoma.


## Seguire la capacità fino a ciò che il destinatario riceve davvero

Segui ogni funzione materiale dal sapere sorgente all’ingresso operativo consumato dal destinatario: kit, avvio, pagina o contesto dell’assistente. Conserva decisioni, ragioni, strumenti forniti e adattamenti locali. Se un assistente usa uno snapshot separato del sapere, la sola pagina aggiornata lascia invariato quel passaggio. Correggi la prima trasformazione responsabile e i suoi dipendenti effettivi. Ogni osservazione resta legata all’edizione esercitata, mentre l’apprendimento riusabile ritorna al metodo di formazione.


## Rendere percepibile la maturità del metodo nel primo incontro reale

L’edizione dei file identifica una distribuzione; la fonte stabilisce la maturità del metodo e la portata delle prove. Conserva questa distinzione dove cambia l’adozione. Segui l’informazione fino al campo realmente consumato dalla pagina o dall’interfaccia del ricevente, oltre che nel metodo, nella guida e nell’avvio. Uno stato nel catalogo può non alimentare l’introduzione visibile. Osserva il primo incontro generato e correggi la proiezione responsabile, conservando la capacità disponibile e la sua profondità utile.


## La pagina spiega la risorsa; il testo copiabile consegna il metodo

Distingui la spiegazione per la persona dalle istruzioni per l’AI. Raggiungi lo standard espressivo del progetto e il sapere dell’owner prima di scrivere. Rendi riconoscibili titolo e contesto, che cosa è la risorsa, che cosa fa, a cosa serve, perché esiste e che cosa significa per il progetto nominato. Queste relazioni possono guidare una pagina breve; il formato concreto segue il destinatario. Il «noi» ha un referente esplicito e non attribuisce pensieri al lettore. Ulteriore materiale serve quando migliora la comprensione. Mantieni una sezione identificabile «Testo da copiare nel proprio LLM»: un avvio completo contiene metodo e sapere necessario; una richiesta breve dichiara file e accessi richiesti; un percorso di configurazione spiega quali istruzioni produce. La sintesi della pagina non sostituisce il metodo.


## Metadati, percorsi e archivi nella distribuzione reale

Quando un generatore trasforma metadati in file, archivi o HTML, usa la competenza di sicurezza pertinente a quel confine. Verifica destinazioni risolte entro la radice affidata, collegamenti del filesystem, identificatori, membri e collisioni degli archivi prima delle scritture; codifica ogni valore nel contesto in cui il browser lo interpreta. L’uguaglianza con Git non prova queste proprietà. Risolvi un riferimento mobile nell’identità sorgente effettivamente letta. Conserva i byte di un archivio già distribuito; una correzione della sua provenienza esterna non riscrive il contenuto storico. Un difetto nel generatore richiede una correzione del meccanismo nel suo owner, entro il mandato; la sola istruzione testuale non lo rende sicuro.


## Un’attività completa conserva incarico e fase propri

Una competenza insegna un saper fare; un’attività completa gli affida un oggetto, uno scopo e un seguito. Riusa le competenze pertinenti senza creare duplicati. Conserva nel trasferimento fase, autorità e condizioni dell’attività sorgente: una proposta da valutare non diventa una correzione già applicata o un’autorizzazione stabile. I raccordi privati ai veri owner restano nelle guide interne; il destinatario riceve contesto e mezzi accessibili. Un nuovo segnale raccolto, una ricevuta o una variazione del calendario non richiedono da soli un’edizione del metodo.

## Continuare attraverso il progetto reale

Un problema di comprensione cambia la scheda o la spiegazione; una lacuna d’uso cambia metodo, guida o attivazione; una divergenza fra sorgente e pacchetto cambia il meccanismo di costruzione. Correggi le proiezioni realmente dipendenti, preservando gli altri lavori.

Conserva fonte, ragione e conseguenza che miglioreranno la prossima risorsa. Una prima realizzazione rende il metodo disponibile e documenta il proprio caso; una diversa adozione successiva può mostrarne limiti e capacità.

## Sapere operativo

Leggi GUIDA_OPERATIVA_IT.md ed ESEMPI_IT.md. Senza accesso ai file usa AVVIO_CHAT_IT.txt completo. Il metodo si compone con le competenze complementari del progetto; strumenti effettivi, persistenza ed effetti autorizzati appartengono al ricevente.
