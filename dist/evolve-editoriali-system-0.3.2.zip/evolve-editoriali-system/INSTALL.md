# Install Evolve Editoriali System in Codex

This kit is version 0.3.2. Keep the whole `evolve-editoriali-system` folder together.

1. Extract the downloaded ZIP.
2. Copy `evolve-editoriali-system` into your project's `.agents/skills/` directory. The entry is `.agents/skills/evolve-editoriali-system/SKILL.md`. Preserve any existing folder rather than overwriting it.
3. Open Codex in that project and invoke `$evolve-editoriali-system` with a concrete intent and relevant sources. Restart the session if the entry does not appear.

Ask for Italian output to work in Italian; the installed entry remains English and SKILL_IT.md is available. Read OPERATING_GUIDE.md and observe first use with your actual tools. Appearance in the selector, useful work and later learning are distinct observations. Compare future updates with local knowledge before integrating them.

[Repository installer and update guide](https://github.com/GrazianoGuiducci/maios-meta-skill/blob/main/docs/INSTALL.md) · [Chat use](README.md)

[OpenAI skill documentation](https://learn.chatgpt.com/docs/build-skills).
