---
name: organizzare-lavoro-complesso
description: "Ricostruisce ciò da cui il lavoro prende senso, collega i piani che partecipano e lascia cambiare domanda e metodo quando emergono relazioni nuove. Usare quando: Quando idee, attività, strumenti e priorità sono mescolati e una lista di task non basta a comprendere come procedere."
---

# Meta_Metodo

**Organizzare un lavoro complesso con l’AI**

Meta_Metodo forma il modo di affrontare un lavoro mentre la situazione diventa comprensibile. Collega intento, oggetto, decisioni già emerse, possibilità, conoscenze, competenze e mezzi; il metodo può cambiare insieme alla domanda.

Usalo quando il racconto mescola idee, strumenti, priorità e risultati attesi, oppure quando una prima soluzione rischia di decidere da sola ciò che il progetto può diventare.

## Ritrovare da che cosa il lavoro prende senso

Comprendi l’intento dell’operatore, l’oggetto presente, le ragioni e ciò che è già determinato. Il primo elemento raccontato non è necessariamente l’origine causale del lavoro; l’ultimo non è necessariamente il suo risultato. Una richiesta di usare uno strumento può esprimere un bisogno più ampio. Tieni raggiungibile la relazione sorgente e permetti al sapere pertinente di cambiarne la comprensione. Conserva decisioni autentiche: non riaprirle soltanto per mantenere astrattamente tutte le possibilità.

## Far partecipare conoscenze e mezzi

Apri le fonti e i metodi delle competenze che possono cambiare il lavoro. Un indice aiuta a trovare il sapere; non ne sostituisce la lettura. Le risorse non sono soltanto strumenti da scegliere dopo avere deciso la soluzione: una conoscenza, una persona o un mezzo possono cambiare la domanda e ciò che diventa realizzabile. Distingui ciò che una fonte spiega, ciò che una competenza sa fare, ciò che uno strumento esegue e ciò che una persona decide. Componili per la relazione utile, senza imporre un gruppo fisso o caricare tutto il sistema.

## Comprendere piani e relazioni

Mantieni distinguibili intento, fatti, ipotesi, possibilità, metodo ed effetti quando confonderli cambia il risultato. Un dato può correggere una scelta senza diventare autorità su ogni aspetto del progetto. Una possibilità può orientare la preparazione senza essere già una capacità disponibile. Un effetto concreto dipende dai suoi strumenti e dal mandato effettivo. Queste distinzioni consentono di connettere i piani; non devono diventare silos, classificazioni obbligatorie o permessi preventivi per pensare.

## Lasciare che il lavoro formi il metodo

Quando il campo è sufficiente, produci il prossimo risultato utile. Può essere una costruzione, una fonte recuperata, una domanda più precisa o una possibilità ancora da lasciare aperta. Se la prima lettura ha ristretto il problema, torna alla fonte dal contesto che hai ora compreso: il nuovo sapere può mostrare una relazione che prima non partecipava. Cambia domanda, rappresentazione, competenze o scala se quella differenza è materiale. La rilettura non è una conferma indipendente e non richiede un numero prestabilito di passaggi. Fermati quando un ulteriore giro riproduce soltanto la stessa forma.

## Integrare ciò che cambia il seguito

Rendi il risultato utilizzabile nel luogo del progetto che ne possiede il significato. Conserva le ragioni del metodo e il contributo delle competenze ancora necessarie quando il lavoro attraversa sessioni. Una correzione di dominio cambia il metodo di dominio; una perdita nel modo di organizzare cambia questa competenza; un ingresso che non raggiunge sapere esistente va ricollegato. Mantieni fonte, interpretazione ed effetto distinguibili. Non creare un nuovo manager o un nuovo documento se la capacità utile è già presente e manca solo il collegamento.

## Il metodo come oggetto del metodo

Meta_Metodo opera sul modo in cui il lavoro viene compreso e organizzato: questa è la relazione meta. Il suo oggetto può includere domanda, composizione delle competenze e condizioni che rendono possibile l’azione.

La relazione autologica emerge quando esamina il proprio organizzare: si accorge, per esempio, che il nome di uno strumento ha selezionato tutte le fonti e ristretto il progetto. Riforma quel metodo mentre continua. Autologica non significa esecuzione autonoma: l’autonomia riguarda mezzi, mandato e condizioni dell’effetto.

## Apprendimento e continuità

Conserva ciò che ha cambiato domanda o metodo e come ritrovarne la sorgente. Un caso riuscito può insegnare una nuova forma di organizzazione senza renderla obbligatoria per tutti i lavori.

La guida deve consentire al prossimo uso di partire dalla comprensione acquisita. Se il metodo diventa una lista rituale, torna alla relazione che quella struttura doveva rendere possibile e mantieni solo ciò che cambia il lavoro.
