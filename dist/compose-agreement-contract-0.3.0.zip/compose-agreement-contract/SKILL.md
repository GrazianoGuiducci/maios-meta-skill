---
name: compose-agreement-contract
description: "Forms the agreement architecture from parties, intended outcome, exchanges and dependencies so the document can express those relations precisely."
metadata:
  version: 0.3.0
  language: en
---

# Compose Agreement Contract

Form an agreement's architecture from parties, intended result, exchanges and dependencies. Make scope, contributions, rights, obligations and unresolved choices explicit before drafting.

Use this competence when a collaboration or service needs a clear agreement and standard clauses do not describe the work. Relations clear in separate conversations may conflict when combined. Form an inspectable, revisable architecture. Document precision comes from the actual relation; legal sufficiency requires the sources and qualified competences pertinent to the case.

## Understand what should become possible

Begin with the intended result and relationship sources: participating people or organizations, actual roles, object and discussion state. Do not immediately fit the case into a standard contract. A map of issues to agree may be the useful first result. Preserve the person's words and choices while keeping unresolved matters visible.

## Connect contributions and dependencies

Make understandable who offers what, to whom, when and under which conditions. Connect performance, resources, payments, access and acceptance evidence where relevant. A delivery may depend on materials another party must provide; payment may reference an event nobody has defined. Bring these relations into one field before drafting apparently precise commitments.

## Compose the necessary knowledge

Project knowledge clarifies feasibility and deliverables; economic knowledge clarifies exchanges and negotiating position; writing gives definitions and consequences precision. None should invent the truth owned by another. For use as a legal instrument, reach current primary sources for the jurisdiction and the qualified legal competence needed. If unavailable, prepare structure and precise review questions without claiming legal sufficiency.

## Form a coherent whole

Consider rights, obligations, conditions, duration, changes, exit and continuing relations where they affect the agreement. Ownership, reuse, data and confidentiality may matter in one case and be absent in another. Do not fill unknowns with conventional wording. Understand how definitions interact: a responsibility, deadline or acceptance criterion can change other sections' meaning.

## Choose the form serving discussion

The result may be a relationship map, term structure, draft or comparison with a received document. Write so parties can see what is aligned and what needs a choice. A counterpart's response can change the next agreement without rewriting the provenance of earlier requests. Distinguish proposal, revision, acceptance, signature and performance.

## Preserve authority and learning

Composing and writing do not send, accept, sign, pay, transfer rights or grant access. Keep each effect connected to the relevant person, means and authorization. After a real case, retain what changes later composition: hidden dependencies, ambiguous definitions, missing evidence or confused roles. Return legal learning to qualified sources and project or writing learning to their own methods.

## Method depth

The object is an agreement's architecture. This is a domain competence that can compose other knowledge; composition alone does not make it a competence generator or autological faculty.

It can learn about its own method when a case reveals an ignored dependency, such as delivery depending on client data that the structure failed to expose. Correcting composition helps later agreements without providing a legal guarantee or authority to bind parties.

## Learning and continuation

A concrete case can change recognition of dependencies and responsibilities. Retain the correction's reasons and let each new context determine pertinent relations rather than making every clause universal.

Begin from available context and sources. The method can operate in chat; persistence, tools and external actions follow the recipient's means and mandate. Observe behavior and value in real work.
## Reachable operating knowledge

Read [OPERATING_GUIDE.md](OPERATING_GUIDE.md) as part of this method when forming the work. It carries the practical knowledge, decision relations and available means for this capability. The complete chat starter includes this knowledge and worked examples, so it remains usable without private sources. Preserve the public source identity and adapt through the recipient's actual means.
