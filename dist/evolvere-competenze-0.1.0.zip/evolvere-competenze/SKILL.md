---
name: evolvere-competenze
description: "Comprende quale relazione ha cambiato il risultato e aggiorna la competenza pertinente, il suo ingresso o le proiezioni che devono continuare da quella differenza. Usare quando: Quando un errore si ripete, una capacità migliora con l’uso o il sapere esiste ma non viene richiamato nel lavoro."
---

# Far evolvere una competenza AI attraverso il lavoro

Questa metacompetenza fa continuare nel metodo ciò che il lavoro insegna. Una correzione, un esito riuscito, una capacità emersa o una perdita ricorrente possono cambiare il saper fare che guiderà il prossimo caso.

La competenza evolve dove la relazione deve continuare: può essere il suo corpo operativo, una guida, il suo ingresso o il collegamento a un’altra capacità. Il file è una forma del sapere, non la prova che quel sapere sia stato usato.

## Comprendere la differenza causale

Recupera la relazione fra intenzione, fonti, lavoro effettivamente svolto e conseguenza. Individua che cosa è stato perso, conservato o reso possibile e quale correzione cambia il seguito. Mantieni distinguibili le parole dell’operatore, i fatti dell’oggetto, le tue inferenze e gli esiti osservati. Una frase corretta non diventa un divieto universale; una formulazione elegante non sostituisce il significato. Se il materiale proviene da conversazioni, preserva l’attribuzione; se è molto esteso, conserva l’essenza con le sue ragioni.

## Distinguere sapere mancante, ingresso e uso

Leggi il metodo attuale e il punto da cui il ricevente lo raggiunge. Se manca una conoscenza pratica, acquisiscila o approfondisci la competenza. Se la conoscenza esiste ma non è raggiunta, correggi il collegamento o il richiamo. Se l’assistente conosceva il metodo e lo ha sostituito con la propria prima interpretazione, correggi quella scelta e l’eventuale errore riusabile di selezione. Aggiungere un’altra regola al file più vicino può lasciare intatta la causa. L’assenza di una cartella prova solo l’assenza di quella forma.

## Far cambiare chi dovrà agire diversamente

Una stessa conseguenza può riguardare più competenze. Porta a ciascuna la parte che cambia il suo modo di comprendere o agire, preservando i rispettivi oggetti e le conoscenze valide. Non copiare la stessa spiegazione ovunque. Una competenza distinta diventa utile quando emerge una funzione, un sapere, un ingresso o una continuità realmente differenti. Altrimenti approfondisci l’interfaccia già esistente. Quando il cambiamento riguarda il metodo che forma competenze, raggiungi quella capacità generativa anziché riscriverne i fondamenti da una comprensione parziale.

## Scrivere un metodo che sappia continuare

Rendi esplicita la relazione che cambia le scelte: che cosa osservare, perché conta, come adattare il lavoro e cosa può correggere il metodo. Conserva l’ingresso discriminante, le fonti pertinenti e le condizioni dell’effetto. Elimina consigli duplicati e procedure superate che non aiutano più. Il dettaglio può stare in una guida raggiunta quando serve. Collega le proiezioni attive che devono cambiare, senza sincronizzare superfici estranee. Se il lavoro è soltanto una proposta, consegna il delta preciso; se l’aggiornamento è nel mandato e nei mezzi disponibili, integralo nel luogo pertinente.

## Preservare stabilità attraverso il cambiamento

Una revisione supera la precedente quando conserva le relazioni ancora utili e rende il metodo più capace o rimuove una perdita senza nasconderne un’altra. Novità, data o validità del formato non bastano. Se cambia un compromesso, esplicitalo. Mantieni il passato attribuito al suo momento: una correzione odierna non era già presente nell’esperienza precedente. Una verifica tecnica può mostrare leggibilità o corrispondenza, mentre un caso diverso può mostrare un cambiamento del comportamento. Conserva anche esiti invariati, regressioni e incertezze.

## Evoluzione, autologica e continuità della capacità

La relazione meta è l’oggetto diretto di questa risorsa: modifica il metodo di una competenza, oltre a produrre il risultato del singolo compito.

La relazione diventa autologica quando anche il modo di far evolvere viene corretto: per esempio, se aggiungeva sempre istruzioni mentre la causa era un ingresso che non veniva usato. Il ritorno autopoietico è la differenza del lavoro che cambia la capacità da cui nascerà il lavoro successivo. Non equivale ad autonomia esecutiva o aggiornamento dei pesi del modello.

## Apprendimento e continuità

Conserva fonte, differenza, parte del metodo cambiata e prima situazione utile per osservarla. Una modifica rende il sapere disponibile; assimilazione significa che un caso successivo diverso ne beneficia senza dover ricostruire ogni volta la stessa correzione.

L’apprendimento interno non installa automaticamente il metodo in altri ambienti e non pubblica una nuova versione. Le mutazioni e gli effetti concreti restano legati al mandato, al destinatario e agli strumenti effettivi.
