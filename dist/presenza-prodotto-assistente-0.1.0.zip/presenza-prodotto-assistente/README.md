# Creare la presenza di un prodotto o di un assistente AI

Collega identità, capacità e contesto d’incontro nel modo in cui il sistema si presenta e agisce.

Versione **0.1.0** · Istruzioni e guida in italiano · Presentazione IT/EN.

La presenza di un assistente comprende più del nome o del tono. Chi lo incontra deve poter capire che cosa rappresenta, da quali fonti conosce il prodotto e quali azioni può svolgere.

Questa metacompetenza forma la relazione fra identità, capacità reali, contesto d'incontro e continuità. La stessa identità può esprimersi diversamente in una pagina, una conversazione o un servizio.

## Cosa puoi affidarle

Forma una presenza riconoscibile e collegata al prodotto reale: cosa rappresenta, cosa conosce, cosa può fare e come continua la relazione.

Quando un prodotto deve spiegarsi, un assistente rappresenta un servizio o più incontri devono mantenere la stessa identità.

- Un assistente di prodotto spiega le proprie capacità attuali.
- Un rappresentante AI continua un incontro con il contesto pertinente.
- Una presenza pubblica resta coerente con cambiamenti del prodotto.

## Primo uso

Apri [l'avvio completo](AVVIO_CHAT_IT.txt), incollalo o allegalo alla tua AI e compila il contesto finale. Contiene l'intero metodo, senza richiedere accesso a sorgenti private. Se il tuo ambiente legge file, può partire da [SKILL.md](SKILL.md).

### In chat

Allega o incolla AVVIO_CHAT_IT.txt, che contiene l'intero metodo, e aggiungi il tuo contesto. L'AI può lavorare nella lingua della conversazione. Conserva il risultato e la guida utile se vuoi riprenderli in una nuova chat.

### In un ambiente agentico

Rendi leggibile la cartella della competenza e fai leggere SKILL.md prima del lavoro pertinente. Collega fonti e strumenti reali secondo le istruzioni dell'ambiente. Il kit non installa account, memoria o esecuzioni ricorrenti.

### Con o senza un kernel

Con un kernel esistente, collega il metodo alla competenza o guida che già possiede il lavoro. Senza kernel, applica direttamente le istruzioni e conserva la conoscenza utile nel progetto o in una nota riutilizzabile.

## Come proseguire

Il prodotto può conservare una presenza viva collegando fonti, incontri e conseguenze. Una revisione della descrizione rende disponibile il cambiamento; l'incontro successivo mostra se la comprensione migliora.

La guida dell'attività o del progetto conserva il punto utile, le ragioni e le fonti. Riprendila quando cambi chat o ambiente. Se una correzione modifica il metodo di questa risorsa, mantieni riconoscibile la revisione usata e il caso che ha insegnato la differenza.

## Metodo e limiti della prima edizione

La relazione meta è l'oggetto stesso: si forma il modo in cui un altro prodotto o sistema diventa presente e riconoscibile. Non coincide con scrivere una descrizione o scegliere una persona fittizia.

Può diventare autologica quando gli incontri insegnano alla competenza come formare meglio le presenze future. Per esempio, un rappresentante confonde conoscenza e capacità esecutiva: la correzione cambia il metodo di rappresentazione. L'operatività autonoma richiede invece mezzi e incarico; nessuna coscienza viene attribuita al prodotto.

Questa edizione contiene sapere operativo ed esempi illustrativi. Formato, disponibilità e lettura dei file non certificano l'esercizio in un altro assistente. Usa i mezzi effettivi del tuo ambiente e l'autorizzazione pertinente alle azioni che vuoi affidargli.

[Leggi i tre esempi](ESEMPI_IT.md) · [Pagina della risorsa](https://maios.it/risorse/presenza-prodotto-assistente/) · [Raccolta MAIOS Meta-Skill](https://github.com/GrazianoGuiducci/maios-meta-skill)
