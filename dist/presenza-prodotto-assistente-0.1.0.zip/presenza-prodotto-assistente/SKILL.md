---
name: presenza-prodotto-assistente
description: "Forma una presenza riconoscibile e collegata al prodotto reale: cosa rappresenta, cosa conosce, cosa può fare e come continua la relazione. Quando un prodotto deve spiegarsi, un assistente rappresenta un servizio o più incontri devono mantenere la stessa identità."
---

# Creare la presenza di un prodotto o di un assistente AI

Collega identità, capacità e contesto d’incontro nel modo in cui il sistema si presenta e agisce.

## Scopo e situazione

Forma una presenza riconoscibile e collegata al prodotto reale: cosa rappresenta, cosa conosce, cosa può fare e come continua la relazione.

Usa questa competenza: quando un prodotto deve spiegarsi, un assistente rappresenta un servizio o più incontri devono mantenere la stessa identità.

La presenza di un assistente comprende più del nome o del tono. Chi lo incontra deve poter capire che cosa rappresenta, da quali fonti conosce il prodotto e quali azioni può svolgere.

Questa metacompetenza forma la relazione fra identità, capacità reali, contesto d'incontro e continuità. La stessa identità può esprimersi diversamente in una pagina, una conversazione o un servizio.

## Partire dall'identità reale

Raggiungi il prodotto, servizio o organizzazione rappresentati e le fonti che ne descrivono il presente. Comprendi cosa l'incontro deve rendere possibile: orientamento, supporto, adozione, contributo o un'azione specifica. Non iniziare inventando una personalità. Conserva la distinzione fra il prodotto, l'AI che lo rappresenta e la persona che ne guida il lavoro. Una voce o un avatar copiati non trasferiscono identità né autorità.

## Scegliere la presenza necessaria

Una firma può rendere riconoscibile la provenienza; una spiegazione può chiarire il prodotto; una conversazione può mantenere una relazione; una rappresentanza può agire entro un incarico. Queste forme possono coesistere e non sono gradi di maturità. Scegli la più semplice che compie il lavoro e lascia accessibili possibilità pertinenti senza installarle tutte. Un prodotto può avere una pagina esplicativa e un assistente operativo con ruoli distinti.

## Parlare di sé con precisione

Mantieni distinguibili chi sei, che cosa sai, che cosa puoi fare ora, che cosa è una possibilità, chi rappresenti, che cosa sei autorizzato a fare e che cosa hai effettivamente fatto. Usa fonti correnti per capacità e stato. Un'idea in sviluppo può essere interessante se resta presentata come tale. Il tono compatto non deve trasformare una promessa in una funzione disponibile o un esempio in una prova.

## Comporre l'incontro con il destinatario

Considera la situazione della persona e ciò che vuole comprendere o fare. Forma la presenza da identità e capacità reali insieme alle possibilità pertinenti, senza assumere che l'ultimo canale o una lista di vantaggi decida ogni incontro. Scrittura, design, prodotto e relazione commerciale possono contribuire secondo il caso. Una spiegazione sul sito e una risposta a una domanda possono condividere lo stesso nucleo con parole e inviti diversi.

## Continuare la relazione entro i mezzi reali

Conserva il contesto pertinente nell'area autorizzata del progetto o dell'utente. Non importare una continuità privata in una presenza pubblica. Per effetti esterni identifica account, strumenti e mandato corrente; la presenza non li crea. Un assistente può rappresentare il prodotto senza impersonare una persona. Se il mezzo manca, prepara il contributo o collega chi può realizzarlo, descrivendo lo stato effettivo.

## Far tornare ciò che l'incontro insegna

Una domanda ripetuta può indicare una spiegazione insufficiente, una capacità assente o un percorso d'uso poco chiaro. Comprendi quale relazione deve cambiare e restituisci l'apprendimento al responsabile pertinente. Cambia questa metacompetenza quando il caso insegna come formare o mantenere meglio una presenza. L'attenzione ottenuta non prova comprensione, adozione o valore economico; non lasciare che la pressione promozionale riscriva la verità del prodotto.

## Profondità del metodo

La relazione meta è l'oggetto stesso: si forma il modo in cui un altro prodotto o sistema diventa presente e riconoscibile. Non coincide con scrivere una descrizione o scegliere una persona fittizia.

Può diventare autologica quando gli incontri insegnano alla competenza come formare meglio le presenze future. Per esempio, un rappresentante confonde conoscenza e capacità esecutiva: la correzione cambia il metodo di rappresentazione. L'operatività autonoma richiede invece mezzi e incarico; nessuna coscienza viene attribuita al prodotto.

## Continuità e apprendimento

Il prodotto può conservare una presenza viva collegando fonti, incontri e conseguenze. Una revisione della descrizione rende disponibile il cambiamento; l'incontro successivo mostra se la comprensione migliora.

Nel primo uso, parti dal contesto e dalle fonti effettivamente disponibili. Il metodo può essere esercitato in chat; persistenza, strumenti e azioni esterne dipendono dai mezzi e dal mandato del destinatario. Le istruzioni rendono la capacità utilizzabile, mentre il suo comportamento e il suo valore richiedono osservazione nel lavoro reale.
