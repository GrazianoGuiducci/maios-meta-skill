# Worked examples

Illustrative cases. Conditions, decisions and continuation are supplied to teach the method; these are not reports of customer results.

## A first encounter with MAIOS

A reader sees a catalogue of skills and concludes that MAIOS is a prompt library. The presentation must make the system’s operating relation recognizable: knowledge and competences participate in work, results can change their method, and that generative capability can form further situated kernels. Use one illustrative project and keep the public kernel and deeper sources reachable. The case opens the relation; the catalogue then becomes useful detail rather than the definition of the whole system.


## One system, different useful entrances

An engineer asks how an industrial assistant preserves fault knowledge; a manager asks who must participate; a technician asks what changes during the shift. These are views of one system. Start each encounter from the actual question, connect the same sourced mechanism and expose the relevant depth. The technician can see a concrete handover example; the engineer can reach data and competence relations. Their different views should remain consistent when they meet again.


## A diagram reveals a conceptual error

A map draws every competence beneath a central controller, although the sources describe situated reciprocal participation. Adding a footnote would leave the wrong visual premise intact. Recover the intended relation and recompose geometry, verbs and navigation so that complementary contributions can become visible together. Observe the rendered result and the questions it now supports. Keep the conceptual correction and the design choice with their respective owners for the next map.


## A school office understands what to delegate to AI

The presentation addresses an office preparing replies to families. It begins with familiar work: a new colleague learns regulations, calendar and exceptional cases. The example then explains the assistant’s actual capability: reach project sources and propose a reply with pertinent reasons. In the first configuration a person validates every text; another configuration could entrust recurring summary preparation while retaining appropriate observation. Sending replies to families remains an effect with its own mandate and means. The presentation distinguishes available method, selected configuration and actually observed behavior. The case lets the school recognize work and choose a first delegation without promising complete autonomy or human-like assimilation by the model.


## A maintenance cooperative explains how it will work with an assistant

A maintenance cooperative considers an assistant for preparing intervention reports. Its actual prototype can read supplied reports, propose a checklist and preserve an approved working guide in the project folder. The first explanation begins from a familiar activity: technicians learn why a check matters and carry that reason into later work. It then shows the prototype’s actual sources and the means that preserve a revised method.

The presentation separates the reports it can read, the rules and reasons guiding a proposal, and the environment that can save approved knowledge. A technician can teach the meaning of an observation; the responsible person can compare a proposal with the record; a team can monitor consequences where a service and mandate actually enable an action. These relationships can coexist. The explanation does not promise that a chat becomes an autonomous maintenance service after a prompt or that every task must pass through one adoption sequence.

If a checklist improves, the cooperative’s method of working with AI changes. A later customer-facing service may also develop, with its own construction and evidence. The presentation keeps these two objects connected without treating the future service as delivered. A question from the audience can change the example, depth or proposed next step. This is an illustrative assignment, not a report of an installed customer system.




## A cooperative presents its catalogue service without memorizing the implementation

A cooperative introduces a service that compares archive records. Its spokesperson knows why provenance matters but does not need to memorize the assistant’s folder structure. In rehearsal, the assistant helps them say one complete relation: compare the two records with their sources, and preserve why a correction changes the next comparison. The selected visual and example support that relation; technical sources remain reachable. This is an illustrative exercise.

A participant asks how the service distinguishes an approved correction from a suggestion. The spokesperson keeps direction while the assistant reaches the relevant source and observation, if those means are available. The question can reveal a missing capability, rather than requiring an invented answer. The project owner then understands the changed object; the presenting competence learns a useful bridge. A spoken explanation, a listener’s understanding and an installed service retain separate states. No public performance or client result is claimed.
